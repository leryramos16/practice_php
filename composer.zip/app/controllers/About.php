<?php 

class About extends Controller
{
    public function index()
    {
        echo "This is the About Controller";
    }
}


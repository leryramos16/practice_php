</main>

<footer class="pt-4 pb-4 text-center">
    <p>&copy; <?= date('Y'); ?> MyApp. All rights reserved.</p>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>



</body>
</html>
